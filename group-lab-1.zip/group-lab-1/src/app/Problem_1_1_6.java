package app;

public class Problem_1_1_6 {

    public static void main(String[] args) {
        System.out.println("Hi " + args[2] + ", " + args[1] + ", and " + args[0]);
    }
}
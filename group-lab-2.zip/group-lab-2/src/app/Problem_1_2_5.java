// Truth table in markdown format
// | |1|0|
// ===
// |1|false|true|
// |0|true|false|